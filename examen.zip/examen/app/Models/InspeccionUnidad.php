<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InspeccionUnidad extends Model
{
    use HasFactory;
    protected $table = "inspecciones_unidad";
}
